create schema pharmacy;
set schema pharmacy;

create table T_XBBNC95_Medicine(Mname varchar(20) primary key,price int,Quantity int,Components varchar(20));
insert into T_XBBNC95_Medicine values('paracetamol',10,500,'acetaminophen');
insert into T_XBBNC95_Medicine values('paracetamolA',10,500,'acetaminophen');
insert into T_XBBNC95_Medicine values('paracetamolB',10,500,'acetaminophen');
insert into T_XBBNC95_Medicine values('',0,0,'');

select * from T_XBBNC95_MEDICINE;


create table T_XBBNC95_Patient(phoneNumber varchar(15) primary key,pName varchar(20),address varchar(150));

//drop table T_XBBNC95_Patient;

select * from T_XBBNC95_Patient;

insert into T_XBBNC95_Patient values('8531041104','swetha','Adayar Chennai');

create table T_XBBNC95_DeliveryPerson(phoneNumber varchar(15) primary key,name varchar(20),status varchar(15),currentLocation varchar(30));

select * from T_XBBNC95_DeliveryPerson;

 9898985321  kaviya Free   adayar


 9894593300  eyh  ethyedt ehryers
 paracetamol     10       13 xyz
 paracetamolA    10      500 acetaminophen
 paracetamolB    10      500 acetaminophen
insert into T_XBBNC95_Medicine values('paracetamolC',10,500,'acetaminophen');
insert into T_XBBNC95_Medicine values('paracetamolD',10,500,'acetaminophen');

insert into T_XBBNC95_DeliveryPerson values('987654321','jagan','Free','T.Nagar');
insert into T_XBBNC95_DeliveryPerson values('9899993212','vijay','Free','gandhi nagar');

create table T_XBBNC95_Order(orderid int not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1,INCREMENT BY 1),phoneNumber varchar(15) references T_XBBNC95_Patient(phoneNumber),Mname1 varchar(20),qty1 int,Mname2 varchar(20),qty2 int,Mname3 varchar(20),qty3 int,Mname4 varchar(20),qty4 int,Mname5 varchar(20),qty5 int,status varchar(15))

select * from T_XBBNC95_Order;
delete from T_XBBNC95_Order where orderid=26;

delete from T_XBBNC95_Order where orderid=5;

   //   1 8531041104   150.0  998775455


create table T_XBBNC95_Bill(billid int primary key references T_XBBNC95_Order(orderid),phoneNumber varchar(15) references T_XBBNC95_Patient(phoneNumber),amount float,deliveryid int);

select * from T_XBBNC95_Bill;

//drop table T_XBBNC95_Bill;

//drop table T_XBBNC95_Order;

insert into T_XBBNC95_Order(phoneNumber,Mname1,qty1,Mname2,qty2,Mname3,qty3,Mname4,qty4,Mname5,qty5,status) values('9999998786','paracetamol',1,'paracetamolA',4,'paracetamolB',3,'paracetamolC',465,'paracetamolD',42,'n');


 8591401140  kavi        user

 9898985321  9898985321  delivery

create table login(phoneNumber varchar(15) primary key,password varchar(15),role varchar(20));

insert into login values('9894593021','admin','admin');

insert into login values('8531041104','swetha','user');

insert into login values('987654321','abc','delivery');

select * from login;

//drop table login;

paracetamol
5
paracetamolA
5
paracetamolB
5
paracetamolC
5
paracetamolD
500

 9999998786 
       
 3 9999998786  paracetamol    1 paracetamolA    4 paracetamolB    3 paracetamolC  465 paracetamolD   42 n
 
 SELECT *  from T_XBBNC95_Order where status='n';
 
 select o.orderid,o.phonenumber,b.amount,b.deliveryid from T_XBBNC95_Order o join T_XBBNC95_Bill b on o.orderid=b.billid;
 

 select * from T_XBBNC95_Patient where phoneNumber in (select phoneNumber from T_XBBNC95_Bill);
 
 select * from login;
 
  
 
 9998765453  priya       user

 
CREATE OR REPLACE PROCEDURE checkvalue 
AS 
DECLARE  
   total_rows number(2); 
BEGIN 
    SELECT *  from T_XBBNC95_Order where status='n';
   IF sql%notfound THEN 
      dbms_output.put_line('no orders placed'); 
   ELSIF sql%found THEN 
      total_rows := sql%rowcount;
      dbms_output.put_line( total_rows || ' orders placed '); 
   END IF;  
END; 
  

 
