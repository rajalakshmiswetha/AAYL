package com.inautix.pharmacy1.manager;
import java.io.*;

import com.inautix.pharmacy1.medicine.*;

import java.util.*;

import com.inautix.pharmacy1.medicine.*;
public class ManagerApp {

	static void generateBill(String medicineName1,int quantity1,String medicineName2,int quantity2,String medicineName3,int quantity3,String medicineName4,int quantity4,String medicineName5,int quantity5){
		MedicineDao medicineDao = new MedicineDao();

		List<MedicineBean> medicineList1 = medicineDao.getMedicine(medicineName1);
		Iterator<MedicineBean> itr1 =  medicineList1.iterator();
		MedicineBean m1=itr1.next();
		int price1=m1.getPrice()*quantity1;
		medicineDao.updateMedicineQuantity(medicineName1, m1.getQuantity()-quantity1);
		
		List<MedicineBean> medicineList2 = medicineDao.getMedicine(medicineName2);
		Iterator<MedicineBean> itr2 =  medicineList2.iterator();
		MedicineBean m2=itr2.next();
		int price2=m2.getPrice()*quantity2;
		medicineDao.updateMedicineQuantity(medicineName2, m2.getQuantity()-quantity2);

		
		List<MedicineBean> medicineList3 = medicineDao.getMedicine(medicineName3);
		Iterator<MedicineBean> itr3 =  medicineList3.iterator();
		MedicineBean m3=itr3.next();
		int price3=m3.getPrice()*quantity3;
		medicineDao.updateMedicineQuantity(medicineName3, m3.getQuantity()-quantity3);

		
		List<MedicineBean> medicineList4 = medicineDao.getMedicine(medicineName4);
		Iterator<MedicineBean> itr4 =  medicineList4.iterator();
		MedicineBean m4=itr4.next();
		int price4=m4.getPrice()*quantity4;
		medicineDao.updateMedicineQuantity(medicineName4, m4.getQuantity()-quantity4);

		
		List<MedicineBean> medicineList5 = medicineDao.getMedicine(medicineName5);
		Iterator<MedicineBean> itr5 =  medicineList5.iterator();
		MedicineBean m5=itr5.next();
		int price5=m5.getPrice()*quantity5;
		medicineDao.updateMedicineQuantity(medicineName5, m5.getQuantity()-quantity5);
		
		int price=price1+price2+price3+price4+price5;
		System.out.println("Bill Generated!!!!!");
		
		System.out.println("Name	Quantity	Price   Total");
		System.out.println(m1.getName()+"   "+quantity1+"   "+m1.getPrice()+"    "+price1);
		System.out.println(m2.getName()+"   "+quantity2+"   "+m2.getPrice()+"    "+price2);
		System.out.println(m3.getName()+"   "+quantity3+"   "+m3.getPrice()+"    "+price3);
		System.out.println(m4.getName()+"   "+quantity4+"   "+m4.getPrice()+"    "+price4);
		System.out.println(m5.getName()+"   "+quantity5+"   "+m5.getPrice()+"    "+price5);
		System.out.println("Total price :"+price);

		
		
	}
	public static void main(String[] args) {
		  Scanner in=new Scanner(System.in);
		System.out.println("Enter medicine and Quantity");
		String medicineName1=in.next();
		int quantity1=in.nextInt();
		String medicineName2=in.next();
		int quantity2=in.nextInt();
		String medicineName3=in.next();
		int quantity3=in.nextInt();
		String medicineName4=in.next();
		int quantity4=in.nextInt();
		String medicineName5=in.next();
		int quantity5=in.nextInt();
	MedicineApp medicineApp=new MedicineApp();
	/*System.out.println(medicineApp.checkStock(medicineName1, quantity1));
	System.out.println(medicineApp.checkStock(medicineName2, quantity2));
	System.out.println(medicineApp.checkStock(medicineName3, quantity3));
	System.out.println(medicineApp.checkStock(medicineName4, quantity4));
	System.out.println(medicineApp.checkStock(medicineName5, quantity5));
*/
	if(medicineApp.checkStock(medicineName1, quantity1)&&medicineApp.checkStock(medicineName2, quantity2)&&medicineApp.checkStock(medicineName3, quantity3)&&medicineApp.checkStock(medicineName4, quantity4)&&medicineApp.checkStock(medicineName5, quantity5))
	{
System.out.println("stocks available and order placed successfully");		
	generateBill(medicineName1,quantity1,medicineName2,quantity2,medicineName3,quantity3,medicineName4,quantity4,medicineName5,quantity5);
	}
	else
	{
		System.out.print("OUT OF STOCK!!!!!!!!!!!!!");
	}
	
	
	}
}
