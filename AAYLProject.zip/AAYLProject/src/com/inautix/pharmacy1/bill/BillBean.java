package com.inautix.pharmacy1.bill;

public class BillBean {

int billid;
String phoneNumber;
float amount;
int deliveryid;
public int getBillid() {
	return billid;
}
public void setBillid(int billid) {
	this.billid = billid;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public float getAmount() {
	return amount;
}
public void setAmount(float amount) {
	this.amount = amount;
}
public int getDeliveryid() {
	return deliveryid;
}
public void setDeliveryid(int deliveryid) {
	this.deliveryid = deliveryid;
}
	
}
