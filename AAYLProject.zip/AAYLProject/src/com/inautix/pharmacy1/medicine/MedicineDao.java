package com.inautix.pharmacy1.medicine;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.inautix.pharmacy1.patient.ConnectionManager;

public class MedicineDao {
	
	
	
	
	
public MedicineBean getMedicineBean(String medicineName){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		ResultSet resultset = null;
		MedicineBean medicineBean = new MedicineBean();

		String searchQuery = "SELECT *  from T_XBBNC95_Medicine where Mname = ?  ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, medicineName);		
			
			 resultset = stmt.executeQuery();	
			
			 
			if(resultset.next()) {
				medicineBean.setName(resultset.getString(1));
				medicineBean.setPrice(resultset.getInt(2));
				medicineBean.setQuantity(resultset.getInt(3));
				medicineBean.setComponents(resultset.getString(4));
				
						
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return medicineBean;
	
}
	
	
	

	public List getMedicine(String medicineName){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List medicineList = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT *  from T_XBBNC95_Medicine where Mname = ?  ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, medicineName);		
			
			 resultset = stmt.executeQuery();	
			
			 medicineList = new ArrayList<MedicineBean>();
			 
			while(resultset.next()) {
				MedicineBean medicineBean = new MedicineBean();
				medicineBean.setName(resultset.getString(1));
				medicineBean.setPrice(resultset.getInt(2));
				medicineBean.setQuantity(resultset.getInt(3));
				medicineBean.setComponents(resultset.getString(4));
				
				medicineList.add(medicineBean);
						
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return medicineList;
	
}

	
	public List getMedicineList(){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List medicineList = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT *  from T_XBBNC95_Medicine";
		try {
			 stmt = conn.prepareStatement(searchQuery);
				
		 resultset = stmt.executeQuery();	
			
			 medicineList = new ArrayList<MedicineBean>();
			 
			while(resultset.next()) {
				MedicineBean medicineBean = new MedicineBean();
				medicineBean.setName(resultset.getString(1));
				medicineBean.setPrice(resultset.getInt(2));
				medicineBean.setQuantity(resultset.getInt(3));
				medicineBean.setComponents(resultset.getString(4));
				
				medicineList.add(medicineBean);
						
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return medicineList;
	
}
	
	public int deleteMedicine(String medicineName){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		 int rowCount=0;
	
		String deleteQuery = "delete from T_XBBNC95_Medicine where Mname = ?  ";
		try {
			 stmt = conn.prepareStatement(deleteQuery);
			stmt.setString(1, medicineName);		
			
			  rowCount=stmt.executeUpdate();	
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return rowCount;
		
	
}
	
public int updateMedicineQuantity(String medicineName,int quantity){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		 int rowCount=0;
	
		String updateQuery = "update T_XBBNC95_Medicine set Quantity = ? where Mname = ?  ";
		try {
			 stmt = conn.prepareStatement(updateQuery);
			stmt.setInt(1, quantity);		
			stmt.setString(2, medicineName);		
			
			  rowCount=stmt.executeUpdate();	
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return rowCount;
		
	
}
	


public int updateMedicinePrice(String medicineName,int price){
	
	//step 3: create statement object 
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	 int rowCount=0;

	String updateQuery = "update T_XBBNC95_Medicine set price = ? where Mname = ?  ";
	try {
		 stmt = conn.prepareStatement(updateQuery);
		stmt.setInt(1, price);		
		stmt.setString(2, medicineName);		
		
		  rowCount=stmt.executeUpdate();	
		
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally{
		try {
			
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	return rowCount;
	

}



public int insertMedicine(String medicineName,int price,int quantity,String components){
	
	//step 3: create statement object 
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	 int rowCount=0;

	String insertQuery = "insert into T_XBBNC95_Medicine values(?,?,?,?)";
	try {
		 stmt = conn.prepareStatement(insertQuery);
		 stmt.setString(1, medicineName);		
		stmt.setInt(2, price);
		stmt.setInt(3,quantity);
		stmt.setString(4,components);
		
		  rowCount=stmt.executeUpdate();	
		if(rowCount>0)
		{
			System.out.println("Data inserted successfully");
		}
		else
			
		{
			System.out.println("Can't insert");
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally{
		try {
			
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	return rowCount;
	

}

}
	


