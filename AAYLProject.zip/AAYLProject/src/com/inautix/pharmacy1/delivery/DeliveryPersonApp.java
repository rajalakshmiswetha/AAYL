package com.inautix.pharmacy1.delivery;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.inautix.pharmacy1.patient.PatientBean;
import com.inautix.pharmacy1.patient.PatientDao;

public class DeliveryPersonApp {

	public static void main(String[] args){
		
		 Scanner in=new Scanner(System.in);
		 
		 DeliveryPersonDao deliveryPersonDao=new DeliveryPersonDao();
		 
		 

			//insert functionality
			System.out.println("Enter phoneNumber, name, status, current location to insert into table");
			String phoneNumber=in.next();
			String name=in.next();
			String status=in.next();
			String cLoc=in.next();
			
			int insertRowCount=deliveryPersonDao.insertDeliveryPersonDetails(phoneNumber, name,status,cLoc );
			
			if(insertRowCount>0)
			{
				System.out.println(name+" inserted successfully");
			}
			else{
				System.out.println(name +" can't insert" );
			}
			
			//view patient details
					System.out.println(" DeliveryPerson who are available now");
					//String getDeliveryPersonNumber = in.next();
					
					List<DeliveryPersonBean> deliveryPersonList = deliveryPersonDao.getDeliveryPersonDetails();
					 Iterator<DeliveryPersonBean> itr2 =  deliveryPersonList.iterator();
					if(itr2.hasNext())
					{
					 while(itr2.hasNext()){
						 DeliveryPersonBean deliveryPersonBean = itr2.next();
						System.out.println(deliveryPersonBean.getName()+ " / "+ deliveryPersonBean.getPhoneNumber()+" / "+deliveryPersonBean.getStatus()+" /"+deliveryPersonBean.getCurrentLocation());
					}}
					else
					{
						System.out.println("patient details not found");
					}
			
			
			
			//delete functionality

			System.out.println("Enter delivery person phone number to delete");
			String delPhoneNumber = in.next();
			int delRowCount=deliveryPersonDao.deleteDeliveryPersonDetails(delPhoneNumber);
			if(delRowCount>0)
			{
				System.out.println(delPhoneNumber+" deleted successfully");
			}
			else{
				System.out.println(delPhoneNumber +" not found" );
			}
			
			
			//update address of patients
			
			System.out.println("enter the phoneNumber and status you wish to update");
			String uPhoneNumber=in.next();
			String uStatus=in.next();
	//System.out.println("cloc entered");		
			int updateRowCount=deliveryPersonDao.updateDeliveryPersonCLoc(uPhoneNumber, uStatus);
			if(updateRowCount>0)
			{
				System.out.println("Status updated");
			}
			else{
				System.out.println("can't update Status");
			}
			
			
			
			
		 
	
}
}