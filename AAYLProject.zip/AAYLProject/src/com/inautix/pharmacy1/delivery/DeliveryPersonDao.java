package com.inautix.pharmacy1.delivery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.inautix.pharmacy1.medicine.MedicineBean;
import com.inautix.pharmacy1.patient.ConnectionManager;
import com.inautix.pharmacy1.patient.PatientBean;

public class DeliveryPersonDao {

public int insertDeliveryPersonDetails(String phoneNumber,String name,String status,String cLocation){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		 int rowCount=0;

		String insertQuery = "insert into T_XBBNC95_DeliveryPerson values(?,?,?,?)";
		try {
			 stmt = conn.prepareStatement(insertQuery);
			 stmt.setString(1, phoneNumber);		
			stmt.setString(2, name);
			stmt.setString(3,status);
			stmt.setString(4,cLocation);

			
			  rowCount=stmt.executeUpdate();	
			if(rowCount>0)
			{
				System.out.println("Data inserted successfully");
			}
			else
				
			{
				System.out.println("Can't insert");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return rowCount;
		

	}

	
public int deleteDeliveryPersonDetails(String phoneNumber){
	
	//step 3: create statement object 
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	 int rowCount=0;

	String deleteQuery = "delete from T_XBBNC95_DeliveryPerson where phoneNumber = ?  ";
	try {
		 stmt = conn.prepareStatement(deleteQuery);
		stmt.setString(1, phoneNumber);		
		
		  rowCount=stmt.executeUpdate();	
		
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally{
		try {
			
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	return rowCount;
	

}	

public int updateDeliveryPersonCLoc(String phoneNumber,String status){
	
	//step 3: create statement object 
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	 int rowCount=0;

	String updateQuery = "update T_XBBNC95_DeliveryPerson set status = ? where phoneNumber = ?  ";
	try {
		 stmt = conn.prepareStatement(updateQuery);
		stmt.setString(1, status);		
		stmt.setString(2, phoneNumber);		
		
		  rowCount=stmt.executeUpdate();	
		
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally{
		try {
			
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	return rowCount;
	

}

public List getDeliveryPersonDetails(){
	
	//step 3: create statement object 
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	List deliveryPersonList = null;
	ResultSet resultset = null;
	String searchQuery = "SELECT * from T_XBBNC95_DeliveryPerson where status = ?  ";
	try {
		 stmt = conn.prepareStatement(searchQuery);
		stmt.setString(1, "Free");		
		
		 resultset = stmt.executeQuery();	
		
		 deliveryPersonList = new ArrayList<DeliveryPersonBean>();
		 
		while(resultset.next()) {
			DeliveryPersonBean deliveryPersonBean = new DeliveryPersonBean();
			deliveryPersonBean.setPhoneNumber(resultset.getString(1));
			deliveryPersonBean.setName(resultset.getString(2));
			deliveryPersonBean.setStatus(resultset.getString(3));
			deliveryPersonBean.setCurrentLocation(resultset.getString(4));
			
		
			
			deliveryPersonList.add(deliveryPersonBean);
					
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally{
		try {
			if(resultset != null)
			resultset.close();
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	return deliveryPersonList;

}

}
