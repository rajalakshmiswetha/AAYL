package com.inautix.pharmacy1.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.inautix.pharmacy1.medicine.MedicineBean;
import com.inautix.pharmacy1.patient.ConnectionManager;

public class LoginDao {

public int insertLogin(String phoneNumber,String password,String role){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		 int rowCount=0;

		String insertQuery = "insert into login values(?,?,?)";
		try {
			 stmt = conn.prepareStatement(insertQuery);
			 stmt.setString(1, phoneNumber);		
			stmt.setString(2, password);
			stmt.setString(3,role);

			
			  rowCount=stmt.executeUpdate();	
			if(rowCount>0)
			{
				System.out.println("Data inserted successfully");
			}
			else
				
			{
				System.out.println("Can't insert");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return rowCount;
		}


public int updateLogin(String phoneNumber,String password){
	
	//step 3: create statement object 
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	 int rowCount=0;

	String updateQuery = "update login set password = ? where phoneNumber = ?  ";
	try {
		 stmt = conn.prepareStatement(updateQuery);
		stmt.setString(1, password);		
		stmt.setString(2, phoneNumber);		
		
		  rowCount=stmt.executeUpdate();	
		
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally{
		try {
			
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	return rowCount;
	}


public List getPassword(String phonenumber){
	
	//step 3: create statement object 
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	List loginList = null;
	ResultSet resultset = null;
	String searchQuery = "SELECT * from login where phoneNumber = ?  ";
	try {
		 stmt = conn.prepareStatement(searchQuery);
		stmt.setString(1, phonenumber);		
		
		 resultset = stmt.executeQuery();	
		
		 loginList = new ArrayList<LoginBean>();
		 
		while(resultset.next()) {
			LoginBean loginBean = new LoginBean();
			loginBean.setPhoneNumber(resultset.getString(1));
			loginBean.setPassword(resultset.getString(2));
			loginBean.setRole(resultset.getString(3));
			
			loginList.add(loginBean);
					
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally{
		try {
			if(resultset != null)
			resultset.close();
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	return loginList;

}
	}
