package com.inautix.pharmacy1.servletController;
import com.inautix.pharmacy1.login.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;





/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(Login.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	public void validateLogin(String phonenumber,String password,String role,HttpServletResponse response,HttpServletRequest request)
	{
	
	LoginDao loginDao=new LoginDao();
		
		List<LoginBean> loginList = loginDao.getPassword(phonenumber);
		 Iterator<LoginBean> itr =  loginList.iterator();
		if(itr.hasNext())
		{
		 while(itr.hasNext()){
			 LoginBean loginBean = itr.next();
String userPassword=loginBean.getPassword();
String userRole=loginBean.getRole();

if(userPassword.equals(password)&&userRole.equals(role))
{
	
	
	if(userRole.equals("admin")){
		try {
			RequestDispatcher rd=request.getRequestDispatcher("ViewOrders.jsp");
			HttpSession session=request.getSession();  
	        session.setAttribute("ph",phonenumber);  
            try {
				rd.forward(request,response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	else if(userRole.equals("user")){
		
		try {
			

			 HttpSession session=request.getSession();  
		        session.setAttribute("phno",phonenumber);  
			
			RequestDispatcher rd=request.getRequestDispatcher("patient.html");

            rd.forward(request,response);


		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
else if(userRole.equals("delivery")){
		
		try {
			
			RequestDispatcher rd=request.getRequestDispatcher("deliveryForm.html");
			HttpSession session=request.getSession();  
	        session.setAttribute("ph",phonenumber);  
			
            rd.forward(request,response);


		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	}
else{
	response.setContentType("text/html");
	try {
		PrintWriter out=response.getWriter();
		logger.info("Invalid Login");
		out.print("<h1><b><i>Invalid Login, Try Again !!!!!!!!</i></b></h1>");
		RequestDispatcher rd=request.getRequestDispatcher("Login.html");
try {
	rd.include(request, response);
} catch (ServletException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
		 
		 }
		 }
		else
		{
			
				response.setContentType("text/html");
				try {
					PrintWriter out=response.getWriter();
					logger.info("Invalid Login");
					out.print("<h1>Invalid Login, Try Again !!!!!!!!</h1>");
					RequestDispatcher rd=request.getRequestDispatcher("Login.html");
			try {
				rd.include(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			
		}
	
	
	
	
	}
	
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//validateLogin("9894593021","admin","admin",response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		validateLogin(request.getParameter("phonenumber"),request.getParameter("password"),request.getParameter("role"),response,request);
	
	
		
	}

}
