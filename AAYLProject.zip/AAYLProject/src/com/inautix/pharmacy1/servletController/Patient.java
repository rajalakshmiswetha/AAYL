package com.inautix.pharmacy1.servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.inautix.pharmacy1.medicine.MedicineApp;
import com.inautix.pharmacy1.medicine.MedicineBean;
import com.inautix.pharmacy1.medicine.MedicineDao;
import com.inautix.pharmacy1.order.OrderDao;

/**
 * Servlet implementation class Patient
 */
@WebServlet("/Patient")
public class Patient extends HttpServlet {
	 HttpSession session;
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(Patient.class);
    /**
     * @see HttpServlet#HttpServlet()
     */
	 void generateBill(String medicineName1,int quantity1,String medicineName2,int quantity2,String medicineName3,int quantity3,String medicineName4,int quantity4,String medicineName5,int quantity5){
			
		 MedicineDao medicineDao = new MedicineDao();

			List<MedicineBean> medicineList1 = medicineDao.getMedicine(medicineName1);
			Iterator<MedicineBean> itr1 =  medicineList1.iterator();
			MedicineBean m1=itr1.next();
			int price1=m1.getPrice()*quantity1;
			medicineDao.updateMedicineQuantity(medicineName1, m1.getQuantity()-quantity1);
			
			List<MedicineBean> medicineList2 = medicineDao.getMedicine(medicineName2);
			Iterator<MedicineBean> itr2 =  medicineList2.iterator();
			MedicineBean m2=itr2.next();
			int price2=m2.getPrice()*quantity2;
			if(quantity2!=0)
			medicineDao.updateMedicineQuantity(medicineName2, m2.getQuantity()-quantity2);

			
			List<MedicineBean> medicineList3 = medicineDao.getMedicine(medicineName3);
			Iterator<MedicineBean> itr3 =  medicineList3.iterator();
			MedicineBean m3=itr3.next();
			int price3=m3.getPrice()*quantity3;
			if(quantity3!=0)
			medicineDao.updateMedicineQuantity(medicineName3, m3.getQuantity()-quantity3);

			
			List<MedicineBean> medicineList4 = medicineDao.getMedicine(medicineName4);
			Iterator<MedicineBean> itr4 =  medicineList4.iterator();
			MedicineBean m4=itr4.next();
			int price4=m4.getPrice()*quantity4;
			if(quantity4!=0)
			medicineDao.updateMedicineQuantity(medicineName4, m4.getQuantity()-quantity4);

			
			List<MedicineBean> medicineList5 = medicineDao.getMedicine(medicineName5);
			Iterator<MedicineBean> itr5 =  medicineList5.iterator();
			MedicineBean m5=itr5.next();
			int price5=m5.getPrice()*quantity5;
			if(quantity5!=0)
			medicineDao.updateMedicineQuantity(medicineName5, m5.getQuantity()-quantity5);
			
		
			
			int price=price1+price2+price3+price4+price5;
			logger.info("Bill Generated!!!!!");
			
			System.out.println("Name	Quantity	Price   Total");
			System.out.println(m1.getName()+"   "+quantity1+"   "+m1.getPrice()+"    "+price1);
			System.out.println(m2.getName()+"   "+quantity2+"   "+m2.getPrice()+"    "+price2);
			System.out.println(m3.getName()+"   "+quantity3+"   "+m3.getPrice()+"    "+price3);
			System.out.println(m4.getName()+"   "+quantity4+"   "+m4.getPrice()+"    "+price4);
			System.out.println(m5.getName()+"   "+quantity5+"   "+m5.getPrice()+"    "+price5);
			System.out.println("Total price :"+price);

			
			
		}
	
	void order(HttpServletRequest request, HttpServletResponse response){
		 response.setContentType("text/html");  

		 PrintWriter out=null;
		try {
			out = response.getWriter();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		int quantity2=0;
		int quantity3=0;
		int quantity4=0;
		int quantity5=0;
		String medicineName1=request.getParameter("med1");
		int quantity1=Integer.valueOf(request.getParameter("qty1"));
		String medicineName2=request.getParameter("med2");
		if(request.getParameter("qty2")!="")
		quantity2=Integer.valueOf(request.getParameter("qty2"));
		System.out.println(medicineName2+" "+quantity2);
		String medicineName3=request.getParameter("med3");
		if(request.getParameter("qty3")!="")
		 quantity3=Integer.valueOf(request.getParameter("qty3"));
		String medicineName4=request.getParameter("med4");
		if(request.getParameter("qty4")!="")
		quantity4=Integer.valueOf(request.getParameter("qty4"));
		String medicineName5=request.getParameter("med5");
		if(request.getParameter("qty5")!="")
		quantity5=Integer.valueOf(request.getParameter("qty5"));
		
	MedicineApp medicineApp=new MedicineApp();
	logger.info("Entered order");
	if(medicineApp.checkStock(medicineName1, quantity1)&&medicineApp.checkStock(medicineName2, quantity2)&&medicineApp.checkStock(medicineName3, quantity3)&&medicineApp.checkStock(medicineName4, quantity4)&&medicineApp.checkStock(medicineName5, quantity5))
	{
		 OrderDao orderDao=new OrderDao();
		 String name=(String)session.getAttribute("phno");  
//System.out.println("stocks available and order placed successfully");
		int insertRowCount=orderDao.insertOrder(name,medicineName1,quantity1,medicineName2, quantity2,medicineName3, quantity3,medicineName4, quantity4,medicineName5, quantity5,"n");
		
		if(insertRowCount>0)
		{
			logger.info(" Inserted successfully");
	
		
		try{
     out=response.getWriter();
out.print("<body bgcolor='#E6E6FA'>");

logger.info("hello  "+name);
out.print("<h1>"+name+"</h1>");
out.print("<h2>order placed Successfully</h2>");
request.getRequestDispatcher("patient.html").include(request, response); 

}
catch(Exception e){}
	//generateBill(medicineName1,quantity1,medicineName2,quantity2,medicineName3,quantity3,medicineName4,quantity4,medicineName5,quantity5);
		}
		else{
			out.print("Server down");
		}
	
	
	}
	else{
	out.println("<body bgcolor='#E6E6FA'><h2> Invalid Order <a href='Pview.jsp'>Check medicine Availability</a></h2>" );
	}
	out.print("</body>");
	}
	
    public Patient() {
        super();
        // TODO Auto-generated constructor stub
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    response.setContentType("text/html");  

		PrintWriter out=response.getWriter();
		
		
		
	 session=request.getSession(false);  
        if(session!=null){  
		
		
		order(request,response);
        }
        else{
        	    
              request.getRequestDispatcher("Login.jsp").include(request, response);  	
        }
	
	}

}
