package com.inautix.pharmacy1.order;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.inautix.pharmacy1.medicine.MedicineBean;
import com.inautix.pharmacy1.medicine.MedicineDao;
import com.inautix.pharmacy1.patient.PatientBean;
import com.inautix.pharmacy1.patient.PatientDao;

public class OrderApp {

	public static void main(String[] args){
		
		 Scanner in=new Scanner(System.in);
		 
		 OrderDao orderDao=new OrderDao();
		 
		
	
	//insert functionality
	System.out.println("Enter phoneNumber,medicine and quantity to insert into table");
	String phoneNumber=in.next();
	
	String mName1=in.next();
	int qty1=in.nextInt();
	
	String mName2=in.next();
	int qty2=in.nextInt();
	
	String mName3=in.next();
	int qty3=in.nextInt();
	
	String mName4=in.next();
	int qty4=in.nextInt();
	
	String mName5=in.next();
	int qty5=in.nextInt();
	
	int insertRowCount=orderDao.insertOrder(phoneNumber,mName1,qty1,mName2,qty2,mName3,qty3,mName4,qty4,mName5,qty5,"n");
	
	if(insertRowCount>0)
	{
		System.out.println(" Inserted successfully");
	}
	else{
		System.out.println(" can't insert" );
	}
	
	//view 
			System.out.println("get details");
			//int getOrderId = in.nextInt();
			
			List<OrderBean> orderList = orderDao.getOrder();
			 Iterator<OrderBean> itr2 =  orderList.iterator();
			if(itr2.hasNext())
			{
			 while(itr2.hasNext()){
				 OrderBean orderBean = itr2.next();
				System.out.println(orderBean.getOrderid()+" "+orderBean.getmName1()+" "+orderBean.getQty1()+" "+orderBean.getmName2()+" "+orderBean.getQty2()+" "+orderBean.getmName3()+" "+orderBean.getQty3()+" "+orderBean.getmName4()+" "+orderBean.getQty4()+" "+orderBean.getmName5()+" "+orderBean.getQty5()+" "+orderBean.getStatus());
			}}
			else
			{
				System.out.println("Order details not found");
			}
	
	
	
	//delete functionality

	System.out.println("Enter Order id to delete");
	int delOrderId = in.nextInt();
	int delRowCount=orderDao.deleteOrder(delOrderId);
	if(delRowCount>0)
	{
		System.out.println(delOrderId+" deleted successfully");
	}
	else{
		System.out.println(delOrderId +" not found" );
	}
	
	//update 
	
	System.out.println("enter the order id and status you wish to update");
	int uOrderId=in.nextInt();
	String uStatus=in.next();
	int updateRowCount=orderDao.updateOrderStatus(uOrderId, uStatus);
	if(updateRowCount>0)
	{
		System.out.println("Status updated");
	}
	else{
		System.out.println("can't update Status");
	}

}
}
