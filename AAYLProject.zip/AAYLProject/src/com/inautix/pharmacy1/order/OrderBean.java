package com.inautix.pharmacy1.order;

public class OrderBean {

private int orderid;
private String phoneNumber;
private String mName1;
private int qty1;
private String mName2;
private int qty2;
private String mName3;
private int qty3;
private String mName4;
private int qty4;
private String mName5;
private int qty5;
private String status;
public int getOrderid() {
	return orderid;
}
public void setOrderid(int orderid) {
	this.orderid = orderid;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public String getmName1() {
	return mName1;
}
public void setmName1(String mName1) {
	this.mName1 = mName1;
}
public int getQty1() {
	return qty1;
}
public void setQty1(int qty1) {
	this.qty1 = qty1;
}
public String getmName2() {
	return mName2;
}
public void setmName2(String mName2) {
	this.mName2 = mName2;
}
public int getQty2() {
	return qty2;
}
public void setQty2(int qty2) {
	this.qty2 = qty2;
}
public String getmName3() {
	return mName3;
}
public void setmName3(String mName3) {
	this.mName3 = mName3;
}
public int getQty3() {
	return qty3;
}
public void setQty3(int qty3) {
	this.qty3 = qty3;
}
public String getmName4() {
	return mName4;
}
public void setmName4(String mName4) {
	this.mName4 = mName4;
}
public int getQty4() {
	return qty4;
}
public void setQty4(int qty4) {
	this.qty4 = qty4;
}
public String getmName5() {
	return mName5;
}
public void setmName5(String mName5) {
	this.mName5 = mName5;
}
public int getQty5() {
	return qty5;
}
public void setQty5(int qty5) {
	this.qty5 = qty5;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}

}
