/**
 * 
 */

function verify()

{

        var id=document.getElementById('allocate').value;

        if (id==null || id==""){
        	 alert("Allocate Id can't be blank");  
        	 return false;
        }
        else
        	{
        	return true;
        	}
        
}
