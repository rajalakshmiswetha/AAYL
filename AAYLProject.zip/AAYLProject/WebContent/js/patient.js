/**
 * 
 */

/**
 * 
 */

function verify()
{
	
	 var id2=document.getElementById('presDoc').value;
	 var id3=document.getElementById('med1').value;
	 var id4=document.getElementById('qty1').value;
	 var id5=document.getElementById('med2').value;
	 var id6=document.getElementById('med3').value;
	 var id7=document.getElementById('med4').value;
	 var id8=document.getElementById('med5').value;
	 
	 var id9=document.getElementById('qty2').value;
	 var id10=document.getElementById('qty3').value;
	 var id11=document.getElementById('qty4').value;
	 var id12=document.getElementById('qty5').value;


	 
    
     if(id2==null || id2==""){
     	 alert("Prescribed Doctor can't be blank");  
     	 return false;
     }
      if(id3==null || id3==""){
     	 alert("Medicine 1 can't be blank");  
     	 return false;
     }
     if(id4==null || id4==""){
     	 alert("Quantity for medicine 1 can't be blank");  
     	 return false;
     }
     if(id5!=null && id5!="" &&(id9==null || id9=="")){
     	 alert("Quantity for medicine 2 can't be blank");  
     	 return false;
     }
     if(id6!=null && id6!=""&&(id10==null || id10=="")){
     	 alert("Quantity for medicine 3 can't be blank");  
     	 return false;
     }
      if(id7!=null && id7!=""&&(id11==null || id11=="")){
     	 alert("Quantity for medicine 4 can't be blank");  
     	 return false;
     }
      if(id8!=null && id8!=""&&(id12==null || id12=="")){
     	 alert("Quantity for medicine 5 can't be blank");  
     	 return false;
     }
     
     	
     	return true;
     	

}