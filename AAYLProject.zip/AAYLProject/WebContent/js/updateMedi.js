/**
 * 
 */

function verify()
{
	 var id1=document.getElementById('medicine').value;
	 var id2=document.getElementById('quantity').value;
	 
     if(id1==null || id1==""){
     	 alert("Medicine name can't be blank");  
     	 return false;
     }
    
     else if(id2==null || id2==""){
     	 alert("quantity can't be blank");  
     	 return false;
     }
    
     else
     	{
     	return true;
     	}

}