/**
 * 
 */
function verify()
{
	 var id1=document.getElementById('cpwd').value;
	 var id2=document.getElementById('npwd').value;
	 var id3=document.getElementById('conpwd').value;
	 
     if(id1==null || id1==""){
     	 alert("Current password can't be blank");  
     	 return false;
     }
    
     else if(id2==null || id2==""){
     	 alert("New password can't be blank");  
     	 return false;
     }
     else if(id3==null || id3==""){
     	 alert("Confirm password can't be blank");  
     	 return false;
     }
     else if(id2!=id3){
     	 alert("New password doesn't match with confirm password");  

    	 return false;
     }
     
     
     else
     	{
     	return true;
     	}

}