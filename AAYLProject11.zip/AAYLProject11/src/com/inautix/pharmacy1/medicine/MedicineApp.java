package com.inautix.pharmacy1.medicine;
import java.util.*;

public class MedicineApp {
	
	
public boolean checkStock(String medicinename,int quantity){
	
	MedicineDao medicineDao = new MedicineDao();
	List<MedicineBean> medicineList = medicineDao.getMedicine(medicinename);
	 Iterator<MedicineBean> itr =  medicineList.iterator();
	 boolean returnvalue=false;
	if(itr.hasNext())
	{
	 while(itr.hasNext()){
		 
		MedicineBean medicineBean = itr.next();
		//System.out.println(medicineBean.getName()+ " / "+ medicineBean.getPrice()+" / "+medicineBean.getQuantity()+" /"+medicineBean.getComponents());
	if(medicineBean.getQuantity()>=quantity)
		{returnvalue= true;
	//System.out.println("yes");
		}
	else
	{
		System.out.println(medicinename);
		returnvalue=false;
	}}}
	else
	{
		//System.out.println("Medicine not found");
returnvalue=false;
	}
	return returnvalue;
	
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		MedicineDao medicineDao = new MedicineDao();
		int choice;
		do{
			
	
		System.out.println("enter option");
		System.out.println("1.view stock 2.delete medicine 3.update medicine 4.insert medicine");
		choice=in.nextInt();
		
		switch(choice){
		
		case 1:
		//search medicine functionality
		System.out.println("Enter medicine name to get details");
		String getMedicineName = in.next();
		
		List<MedicineBean> medicineList = medicineDao.getMedicine(getMedicineName);
		 Iterator<MedicineBean> itr =  medicineList.iterator();
		if(itr.hasNext())
		{
		 while(itr.hasNext()){
			MedicineBean medicineBean = itr.next();
			System.out.println(medicineBean.getName()+ " / "+ medicineBean.getPrice()+" / "+medicineBean.getQuantity()+" /"+medicineBean.getComponents());
		}}
		else
		{
			System.out.println("Medicine not found");
		}
		break;
		case 2:
		//delete functionality
		System.out.println("Enter medicine name to delete");
		String delMedicineName = in.next();
		int delRowCount=medicineDao.deleteMedicine(delMedicineName);
		if(delRowCount>0)
		{
			System.out.println(delMedicineName+" deleted successfully");
		}
		else{
			System.out.println(delMedicineName +" not found" );
		}
		break;
		case 3:
		//update functionality
	System.out.println("enter the medicinename and quantity you wish to update");
	String updateMedicineName=in.next();
	int quantity=in.nextInt();
	int updateRowCount=medicineDao.updateMedicineQuantity(updateMedicineName, quantity);
	if(updateRowCount>0)
	{
		System.out.println(updateMedicineName+"'s Quantity is updated to "+quantity);
	}
	else{
		System.out.println("can't update "+updateMedicineName);
	}
	break;
		case 4:
	//insert functionality
	System.out.println("enter the medicineName,price,quantity,components to enter into table");
	String iMedicineName=in.next();
	int iPrice =in.nextInt();
	int iQuantity=in.nextInt();
	String iComponents=in.next();
	
	int insertRowCount=medicineDao.insertMedicine(iMedicineName, iPrice, iQuantity, iComponents);
	
	
	
	if(insertRowCount>0)
	{
		System.out.println(iMedicineName+" inserted successfully");
	}
	else{
		System.out.println(iMedicineName +" can't insert" );
	}
	break;
	
	default:
		System.out.println("Invalid Input");
		}
	
		}while(choice<5);
	
	}
	
	
	

}
