package com.inautix.pharmacy1.patient;

import java.sql.*;

public class ConnectionManager {
	 static Connection con;
	   	         
	   public static Connection getConnection()
	   {
	     
	      try
	      {
	         
//Class.forName("oracle.jdbc.driver.OracleDriver");

	     	Class.forName("org.apache.derby.jdbc.ClientDriver");
	         
	                    	
	            try {
	              //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
					con = DriverManager.getConnection("jdbc:derby://172.24.19.192:1527/pharmacydb","swetha","swetha");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	      }

	      catch(ClassNotFoundException e)
	      {
	         System.out.println(e);
	      }

	   return con;
	}
}
