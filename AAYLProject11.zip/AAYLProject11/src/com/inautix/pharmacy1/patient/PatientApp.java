package com.inautix.pharmacy1.patient;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.inautix.pharmacy1.medicine.MedicineBean;
import com.inautix.pharmacy1.medicine.MedicineDao;

public class PatientApp {

	public static void main(String[] args){
		
		 Scanner in=new Scanner(System.in);
		 
		 PatientDao patientDao=new PatientDao();
		 
		 
		 
		 
			//search availability of stock before order
			System.out.println("enter medicine name and quantity");
	String medicineName=in.nextLine();
	int quantity=in.nextInt();
	MedicineDao medicineDao = new MedicineDao();

	List<MedicineBean> medicineList = medicineDao.getMedicine(medicineName);
	Iterator<MedicineBean> itr =  medicineList.iterator();
	if(itr.hasNext())
	{
	while(itr.hasNext()){
		MedicineBean medicineBean = itr.next();
		//System.out.println(medicineBean.getName()+ " / "+ medicineBean.getPrice()+" / "+medicineBean.getQuantity()+" /"+medicineBean.getComponents());
	if(medicineBean.getPrice()<quantity)
	{
		System.out.println("Sorry!!!! out of Stock" );
		System.out.println("Currently "+medicineBean.getQuantity()+" "+ medicineBean.getName() +" available");
	}
	else{
		System.out.println("Available in Stock");
	}

	}}
	else
	{
		System.out.println("Medicine not found");
	}
	

	
	
	//insert functionality
	System.out.println("Enter phoneNumber, name, address to insert into table");
	String phoneNumber=in.next();
	String name=in.next();
	String address=in.next();
	
	int insertRowCount=patientDao.insertPatientDetails(phoneNumber, name, address);
	
	if(insertRowCount>0)
	{
		System.out.println(name+" inserted successfully");
	}
	else{
		System.out.println(name +" can't insert" );
	}
	
	//view patient details
			System.out.println("Enter patient number to get details");
			String getPatientNumber = in.next();
			
			List<PatientBean> patientList = patientDao.getPatientDetails(getPatientNumber);
			 Iterator<PatientBean> itr2 =  patientList.iterator();
			if(itr2.hasNext())
			{
			 while(itr2.hasNext()){
				PatientBean patientBean = itr2.next();
				System.out.println(patientBean.getName()+ " / "+ patientBean.getPhonenumber()+" / "+patientBean.getAddress());
			}}
			else
			{
				System.out.println("patient details not found");
			}
	
	
	
	//delete functionality

	System.out.println("Enter patient phone number to delete");
	String delPhoneNumber = in.next();
	int delRowCount=patientDao.deletePatientDetails(delPhoneNumber);
	if(delRowCount>0)
	{
		System.out.println(delPhoneNumber+" deleted successfully");
	}
	else{
		System.out.println(delPhoneNumber +" not found" );
	}
	
	//update address of patients
	
	System.out.println("enter the phoneNumber and address you wish to update");
	String uPhoneNumber=in.next();
	String uAddress=in.next();
	int updateRowCount=patientDao.updatePatientAddress(uPhoneNumber, uAddress);
	if(updateRowCount>0)
	{
		System.out.println("Address updated");
	}
	else{
		System.out.println("can't update address");
	}
	
	
	
	
	
	
	
	}
	
	
	
	
	
}
