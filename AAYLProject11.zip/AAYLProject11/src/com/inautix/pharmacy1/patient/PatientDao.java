package com.inautix.pharmacy1.patient;
import java.util.*;
import java.sql.*;

import com.inautix.pharmacy1.medicine.MedicineBean;
public class PatientDao {

	public int insertPatientDetails(String phoneNumber,String patientName,String address){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		 int rowCount=0;

		String insertQuery = "insert into T_XBBNC95_Patient values(?,?,?)";
		try {
			 stmt = conn.prepareStatement(insertQuery);
			 stmt.setString(1, phoneNumber);		
			stmt.setString(2, patientName);
			stmt.setString(3,address);
			
			
			  rowCount=stmt.executeUpdate();	
			if(rowCount>0)
			{
				System.out.println("Data inserted successfully");
			}
			else
				
			{
				System.out.println("Can't insert");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return rowCount;
		

	}

	
public int deletePatientDetails(String phoneNumber){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		 int rowCount=0;
	
		String deleteQuery = "delete from T_XBBNC95_Patient where phoneNumber = ?  ";
		try {
			 stmt = conn.prepareStatement(deleteQuery);
			stmt.setString(1, phoneNumber);		
			
			  rowCount=stmt.executeUpdate();	
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return rowCount;
		
	
}


public int updatePatientAddress(String phoneNumber,String address){
	
	//step 3: create statement object 
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	 int rowCount=0;

	String updateQuery = "update T_XBBNC95_Patient set address = ? where phoneNumber = ?  ";
	try {
		 stmt = conn.prepareStatement(updateQuery);
		stmt.setString(1, address);		
		stmt.setString(2, phoneNumber);		
		
		  rowCount=stmt.executeUpdate();	
		
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally{
		try {
			
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	return rowCount;
	

}



public List getPatientDetails(String phoneNumber){
	
	//step 3: create statement object 
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	List patientList = null;
	ResultSet resultset = null;
	String searchQuery = "SELECT *  from T_XBBNC95_Patient where phoneNumber = ?  ";
	try {
		 stmt = conn.prepareStatement(searchQuery);
		stmt.setString(1, phoneNumber);		
		
		 resultset = stmt.executeQuery();	
		
		 patientList = new ArrayList<MedicineBean>();
		 
		while(resultset.next()) {
			PatientBean patientBean = new PatientBean();
			patientBean.setPhonenumber(resultset.getString(1));
			patientBean.setName(resultset.getString(2));
			patientBean.setAddress(resultset.getString(3));
		
			
			patientList.add(patientBean);
					
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally{
		try {
			if(resultset != null)
			resultset.close();
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	return patientList;

}

	
}
