package com.inautix.pharmacy1.order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.inautix.pharmacy1.medicine.MedicineBean;
import com.inautix.pharmacy1.patient.ConnectionManager;

public class OrderDao {

	public List getOrder(){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List orderList = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT *  from T_XBBNC95_Order where status='n'";
		try {
			 stmt = conn.prepareStatement(searchQuery);
				
			
			 resultset = stmt.executeQuery();	
			
			 orderList = new ArrayList<OrderBean>();
			 
			while(resultset.next()) {
				OrderBean orderBean = new OrderBean();
				orderBean.setOrderid(resultset.getInt(1));
				orderBean.setPhoneNumber(resultset.getString(2));
				orderBean.setmName1(resultset.getString(3));
				orderBean.setQty1(resultset.getInt(4));
				orderBean.setmName2(resultset.getString(5));
				orderBean.setQty2(resultset.getInt(6));
				orderBean.setmName3(resultset.getString(7));
				orderBean.setQty3(resultset.getInt(8));
				orderBean.setmName4(resultset.getString(9));
				orderBean.setQty4(resultset.getInt(10));
				orderBean.setmName5(resultset.getString(11));
				orderBean.setQty5(resultset.getInt(12));
				orderBean.setStatus(resultset.getString(13));
				
				
				orderList.add(orderBean);
						
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return orderList;
	
}
	
	
public List getOrderDetails(int orderid){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List orderList = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT *  from T_XBBNC95_Order where orderid= ? ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
				
				stmt.setInt(1, orderid);
			 resultset = stmt.executeQuery();	
			
			 orderList = new ArrayList<OrderBean>();
			 
			while(resultset.next()) {
				OrderBean orderBean = new OrderBean();
				orderBean.setOrderid(resultset.getInt(1));
				orderBean.setPhoneNumber(resultset.getString(2));
				orderBean.setmName1(resultset.getString(3));
				orderBean.setQty1(resultset.getInt(4));
				orderBean.setmName2(resultset.getString(5));
				orderBean.setQty2(resultset.getInt(6));
				orderBean.setmName3(resultset.getString(7));
				orderBean.setQty3(resultset.getInt(8));
				orderBean.setmName4(resultset.getString(9));
				orderBean.setQty4(resultset.getInt(10));
				orderBean.setmName5(resultset.getString(11));
				orderBean.setQty5(resultset.getInt(12));
				orderBean.setStatus(resultset.getString(13));
				
				
				orderList.add(orderBean);
						
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return orderList;
	
}

	public String getNumber(int orderid){
		
		 String phoneNumber = null;
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List orderList = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT *  from T_XBBNC95_Order where orderid= ? ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
				
				stmt.setInt(1, orderid);
			 resultset = stmt.executeQuery();	
			
		
			
			while(resultset.next()) {
				phoneNumber=resultset.getString(2);
				}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return phoneNumber;
		
	}
	
	public int deleteOrder(int orderid){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		 int rowCount=0;
	
		String deleteQuery = "delete from T_XBBNC95_Order where orderid = ?  ";
		try {
			 stmt = conn.prepareStatement(deleteQuery);
			stmt.setInt(1, orderid);		
			
			  rowCount=stmt.executeUpdate();	
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return rowCount;
		
	
}
	
public int updateOrderStatus(int orderid,String status){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		 int rowCount=0;
	
		String updateQuery = "update T_XBBNC95_Order set status = ? where orderid = ?  ";
		try {
			 stmt = conn.prepareStatement(updateQuery);
					
			stmt.setString(1, status);		
			stmt.setInt(2, orderid);
			
			  rowCount=stmt.executeUpdate();	
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return rowCount;
		
	
}
	

public int insertOrder(String phoneNumber,String mName1,int qty1,String mName2,int qty2,String mName3,int qty3,String mName4,int qty4,String mName5,int qty5,String status){
	
	//step 3: create statement object 
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	 int rowCount=0;

	String insertQuery = "insert into T_XBBNC95_Order(phoneNumber,Mname1,qty1,Mname2,qty2,Mname3,qty3,Mname4,qty4,Mname5,qty5,status) values(?,?,?,?,?,?,?,?,?,?,?,?)";
	try {
		 stmt = conn.prepareStatement(insertQuery);
		 		
		stmt.setString(1,phoneNumber);
		stmt.setString(2,mName1);
		stmt.setInt(3,qty1);
		stmt.setString(4,mName2);
		stmt.setInt(5,qty2);
		stmt.setString(6,mName3);
		stmt.setInt(7,qty3);
		stmt.setString(8,mName4);
		stmt.setInt(9,qty4);
		stmt.setString(10,mName5);
		stmt.setInt(11,qty5);
		stmt.setString(12,status);
		
		  rowCount=stmt.executeUpdate();	
		if(rowCount>0)
		{
			System.out.println("Data inserted successfully");
		}
		else
			
		{
			System.out.println("Can't insert");
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally{
		try {
			
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	return rowCount;
	

}
	
}
