package com.inautix.pharmacy1.controller;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;

import com.inautix.pharmacy1.medicine.MedicineBean;

public class TestRowMapper implements RowMapper<MedicineBean> {

	public MedicineBean mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		
		MedicineBean medicineObj =new MedicineBean();
		medicineObj.setName(rs.getString(1));
		medicineObj.setPrice(rs.getInt(2));
		medicineObj.setQuantity(rs.getInt(3));
		medicineObj.setComponents(rs.getString(4));
		
		return medicineObj;
	}

}
