package com.inautix.pharmacy1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;




import com.inautix.pharmacy1.medicine.*;


@RestController
@RequestMapping(value = "/stocks")

public class StockController {

	@Autowired
	MedicineDao medicineDao;

	
	  @RequestMapping(value = "/all" , method = RequestMethod.GET )
	  public List<MedicineBean> getAllStocks() {
    	System.out.println("all");
		ArrayList list = new ArrayList<MedicineBean>();  
		list= (ArrayList) medicineDao.getMedicineList();
		
    	return list;
      }	

	  @RequestMapping(value = "/post" , method = RequestMethod.POST )
	  public int putStocks(@RequestBody com.inautix.pharmacy1.medicine.MedicineBean m) {
    	System.out.println("post");
		int retvalue=0;
    	retvalue=medicineDao.insertMedicine(m.getName(), m.getPrice(), m.getQuantity(),m.getComponents());
		return retvalue;
      }	
	
}
