package com.inautix.pharmacy1.servletController;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.inautix.pharmacy1.delivery.DeliveryPersonBean;
import com.inautix.pharmacy1.delivery.DeliveryPersonDao;
import com.inautix.pharmacy1.medicine.MedicineBean;
import com.inautix.pharmacy1.medicine.MedicineDao;

/**
 * Servlet implementation class DeliveryServer
 */
@WebServlet("/DeliveryServer")
public class DeliveryServer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeliveryServer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
	
		
		MedicineDao medicineDao=new MedicineDao();
		
		String medicineName=(String)request.getParameter("medicineName");
		System.out.println(medicineName);
		

	
		
		MedicineBean mBean=medicineDao.getMedicineBean(medicineName);
		
		int price=mBean.getPrice();
		System.out.println(price);

		
		if(price!=0){
			
		
String json = new Gson().toJson(mBean);

response.setContentType("application/json");

response.getWriter().write(json);  

	}
	else{
		
		response.setContentType("text/html");

		response.getWriter().write("Sorry, medicine not available in stock !!!!!");
	
		
		//out.print("<body bgcolor='#E6E6FA'><h2>Sorry, medicine not available in stock !!!!!<h2></body>");
	}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
