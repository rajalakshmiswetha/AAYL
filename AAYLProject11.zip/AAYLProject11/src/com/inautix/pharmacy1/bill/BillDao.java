package com.inautix.pharmacy1.bill;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.inautix.pharmacy1.medicine.MedicineBean;
import com.inautix.pharmacy1.patient.ConnectionManager;

public class BillDao {

	public int insertBill(int billid,String phoneNumber,float amount,int deliveryid){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		 int rowCount=0;

		String insertQuery = "insert into T_XBBNC95_Bill values(?,?,?,?)";
		try {
			 stmt = conn.prepareStatement(insertQuery);
			 stmt.setInt(1, billid);		
			stmt.setString(2, phoneNumber);
			stmt.setFloat(3,amount);
			stmt.setInt(4,deliveryid);
			
			  rowCount=stmt.executeUpdate();	
			if(rowCount>0)
			{
				System.out.println("Data inserted successfully");
			}
			else
				
			{
				System.out.println("Can't insert");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return rowCount;
		

	}
	
	

	public List getBill(int billid){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List billList = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT *  from T_XBBNC95_Bill where billid = ?  ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setInt(1,billid);		
			
			 resultset = stmt.executeQuery();	
			
			 billList = new ArrayList<BillBean>();
			 
			while(resultset.next()) {
				BillBean billBean = new BillBean();
				billBean.setBillid(billid);
				billBean.setAmount(resultset.getFloat(3));
				billBean.setPhoneNumber(resultset.getString(2));
				billBean.setDeliveryid(resultset.getInt(1));
				billList.add(billBean);
						
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return billList;
	
}

	
}
