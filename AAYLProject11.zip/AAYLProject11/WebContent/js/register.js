/**
 * 
 */
/**
 * 
 */
function verify()
{
	 var id1=document.getElementById('phonenumber').value;
	// var id2=document.getElementById('price').value;
	 //var id3=document.getElementById('quantity').value;
	 alert("Medicine name can't be blank");  
	 var phoneno = /^\d{10}$/;  
     if(id1==null || id1==""){
    	 
     	 alert("Medicine name can't be blank");  
     	 return false;
     }
     else
     	{
     	return true;
     	}

}
