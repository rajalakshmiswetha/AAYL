/**
 * 
 */
function verify()
{
	 var id1=document.getElementById('medicine').value;
	
	 
     if(id1==null || id1==""){
     	 alert("Medicine name can't be blank");  
     	 return false;
     }
     else
    	 {
    	 return true;
    	 }
    	 }
     