/**
 * 
 */


function verify()
{
	 var id1=document.getElementById('phonenumber').value;

     if(id1==null || id1==""){
     	 alert("phone number can't be blank");  
     	 return false;
     }
    
     else
     	{
     	return true;
     	}

}