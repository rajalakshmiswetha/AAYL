/**
 * 
 */
/**
 * 
 */

function verify()
{
	 var id1=document.getElementById('phonenumber').value;
	 var id2=document.getElementById('name').value;
	 
     if(id1==null || id1==""){
     	 alert("phone number can't be blank");  
     	 return false;
     }
    
     else if(id2==null || id2==""){
     	 alert("name can't be blank");  
     	 return false;
     }
    
     else
     	{
     	return true;
     	}

}