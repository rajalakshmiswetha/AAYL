/**
 * 
 */
/**
 * 
 */
function verify()
{
	 var id1=document.getElementById('medicine').value;
	 var id2=document.getElementById('price').value;
	 var id3=document.getElementById('quantity').value;
	 var id4=document.getElementById('comp').value;
	 
     if(id1==null || id1==""){
     	 alert("Medicine name can't be blank");  
     	 return false;
     }
     else if(id2==null || id2==""){
     	 alert("price can't be blank");  
     	 return false;
     }
     else if(id3==null || id3==""){
     	 alert("quantity can't be blank");  
     	 return false;
     }
     else if(id4==null || id4==""){
     	 alert("Components can't be blank");  
     	 return false;
     }
     else
     	{
     	return true;
     	}

}
